package org.example.project.api.participacao;

import java.util.Date;

public class ParticipacaoRequest {
	public int id;
	public int idFuncionario;
	public Date data_inicio;
	public Date data_termino;

}
