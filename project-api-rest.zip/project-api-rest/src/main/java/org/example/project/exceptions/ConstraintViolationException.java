package org.example.project.exceptions;

public class ConstraintViolationException {

}
